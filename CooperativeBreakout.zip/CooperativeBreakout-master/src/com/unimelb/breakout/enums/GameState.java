package com.unimelb.breakout.enums;

public enum GameState {

	READY,
	ACTIVE,
	DEAD;
}
